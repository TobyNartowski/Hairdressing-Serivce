create view version as
  select
    '2.0.0'   AS `sys_version`,
    version() AS `mysql_version`;

