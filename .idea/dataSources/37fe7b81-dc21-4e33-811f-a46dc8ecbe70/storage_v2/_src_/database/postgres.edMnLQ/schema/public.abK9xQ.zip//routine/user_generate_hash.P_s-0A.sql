create function user_generate_hash(user_password text, salt text)
  returns text
language plpgsql
as $$
BEGIN
	RETURN encode(digest(concat(user_password, salt), 'sha256'), 'hex');
END;
$$;

