create function user_generate_salt()
  returns text
language plpgsql
as $$
BEGIN
	RETURN encode(digest(concat(uuid_generate_v4(),  uuid_generate_v4()), 'sha256'), 'hex');
END;
$$;

