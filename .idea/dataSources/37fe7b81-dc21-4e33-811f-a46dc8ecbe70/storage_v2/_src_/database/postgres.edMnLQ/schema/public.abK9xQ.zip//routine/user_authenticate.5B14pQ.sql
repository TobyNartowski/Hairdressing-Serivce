create function user_authenticate(user_login text, user_password text)
  returns boolean
language plpgsql
as $$
DECLARE
	fetched_hash text;
	fetched_salt text;
BEGIN
	IF user_exists(user_login) = false THEN
		RETURN false;
	END IF;
	
	SELECT hash INTO fetched_hash FROM users WHERE login = user_login;
	SELECT salt INTO fetched_salt FROM users WHERE login = user_login;
	
	IF fetched_hash = user_generate_hash(user_password, fetched_salt) THEN
		RETURN true;
	ELSE
		RETURN false;
	END IF;
END;
$$;

