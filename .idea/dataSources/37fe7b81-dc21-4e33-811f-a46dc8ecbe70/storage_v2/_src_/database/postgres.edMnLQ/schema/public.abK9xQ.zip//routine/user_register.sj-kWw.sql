create function user_register(user_login text, user_password text)
  returns boolean
language plpgsql
as $$
DECLARE
	generated_salt text = user_generate_salt();
	generated_hash text = user_generate_hash(user_password, generated_salt);
BEGIN
	IF user_exists(user_login) THEN
		RETURN FALSE;	
	END IF;
	
	INSERT INTO users (login, hash, salt) VALUES (user_login, generated_hash, generated_salt);
	RETURN TRUE;
END;
$$;

