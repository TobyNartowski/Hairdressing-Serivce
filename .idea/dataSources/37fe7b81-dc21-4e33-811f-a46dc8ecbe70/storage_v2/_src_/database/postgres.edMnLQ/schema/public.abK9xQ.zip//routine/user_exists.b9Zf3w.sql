create function user_exists()
  returns boolean
language plpgsql
as $$
BEGIN
	
	
END;
$$;

