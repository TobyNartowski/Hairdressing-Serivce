create function user_exists(user_login text)
  returns boolean
language plpgsql
as $$
BEGIN
	IF (SELECT count(*) FROM users WHERE login = user_login) THEN 
		RETURN true;
	ELSE
		RETURN FALSE;
	END IF;
END;
$$;

